def main():
    print("Hello from payload-package!")


if __name__ == "__main__":
    main()
